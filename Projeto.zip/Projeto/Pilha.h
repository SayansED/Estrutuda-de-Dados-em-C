#include <stdio.h>
#include <stdlib.h>

typedef struct pilha Pilha;

// Cabe�alho
Pilha * constroi_pilha(int);

int pilha_cheia(Pilha *);

int pilha_vazia(Pilha *);

int push (int, Pilha *);
// Devolve sucesso ou fracasso '0 or 1'

int pop (int *, Pilha *);
/* Devolve 0 or 1
o elemento sai por referencia */

int tamanho (Pilha *);

int consulta_topo (Pilha *);

void mostra_pilha(Pilha *p);
